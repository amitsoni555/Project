#!/usr/bin/env python
# coding: utf-8

# 
# ### Importing the important libraries

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# ### Loading the DataSet

# In[2]:


df = pd.read_csv('customer_churn.csv', skipinitialspace=True)


# In[3]:


# checking the head of data
df.head()


# In[4]:


# checking information about data
df.info()


# In[5]:


# checking the null values
df.isnull().sum()


# ### As we can see we have Null values in TotalCharges column

# In[6]:


# with the help of unique method we will see why TotalCharges has null value
print (df.TotalCharges.unique().tolist())


# In[7]:


# As we can see we have nan value preset in TotalCharges column and we will remove the null values with dropna function
df = df.dropna()


# In[8]:


# checking the shape to confirm that null values droped or not 
df.shape


# ## Data Manipulation

# In[9]:


# 1.Extract the 5th column and store it in ‘customer_5
# Performing task-1

customer_5 = df.iloc[:,4]
customer_5.head()


# In[10]:


# 2.Extract the 15th column and store it in ‘customer_15’
# performing task-2

customer_15 = df.iloc[:,14]
customer_15.head()


# In[11]:


# Extract all the male senior citizens whose payment method is electronic check and store the result in ‘senior_male_electronic’
# performing task-3

senior_male_electronic = df[(df['PaymentMethod']=='Electronic check') & (df['SeniorCitizen']==1) & (df['gender'] == 'Male')]
senior_male_electronic.head()


# In[12]:


#  Extract all those customers whose tenure is greater than 70 months or their monthly charges 
#  is more than $100 and store the result in ‘customer_total_tenure’
# performing Task-4

customer_total_tenure = df[(df['tenure'] > 70) | (df['MonthlyCharges'] > 100)]
customer_total_tenure.head()


# In[13]:


# Extract all the customers whose contract is of two years, payment method is mailed check and 
# the value of churn is ‘Yes’ and store the result in ‘two_mail_yes’
# performing task-5

two_mail_yes = df[(df['Contract'] == 'Two year') & (df['PaymentMethod'] == 'Mailed check') & (df['Churn'] == 'Yes')]
two_mail_yes.head()


# In[14]:


# Extract 333 random records from the customer_churndataframe and store the result in ‘customer_333’
# Performing Task-6

customer_333 = df.sample(n=333)
customer_333.head()


# In[15]:


# Get the count of different levels from the ‘Churn’ column
# Performing Task-7

sns.histplot(data=df, x=df['Churn'])
plt.title('Histogram')
plt.show()


# ##  Data Visualization

# In[16]:


# Build a bar-plot for the ’InternetService’ column:
# a. Set x-axis label to ‘Categories of Internet Service’
# b. Set y-axis label to ‘Count of Categories’
# c. Set the title of plot to be ‘Distribution of Internet Service’
# d. Set the color of the bars to be 'orange'


# In[17]:


category = df['InternetService'].value_counts().keys()
count_of_category = df['InternetService'].value_counts()


# In[18]:


# Building Barplot
sns.barplot(data=df, x=category, y=count_of_category, color='orange')
plt.xlabel('Categories of Internet Service')
plt.ylabel('Count of Categories')
plt.title('Distribution of Internet Service')
plt.show()


# In[19]:


# Build a histogram for the ‘tenure’ column:
# a. Set the number of bins to be 30
# b. Set the color of the bins to be ‘green’
# c. Assign the title 'Distribution of tenure'


# In[20]:


# Building Histogram
plt.hist(x=df['tenure'], bins=30, color='green')
plt.title('Distribution of Tenure')
plt.show()


# In[21]:


# Build a scatter-plot between ‘MonthlyCharges’ and ‘tenure’. Map
# ‘MonthlyCharges’ to the y-axis and ‘tenure’ to the ‘x-axis’:
# a. Assign the points a color of ‘brown’
# b. Set the x-axis label to ‘Tenure of customer’
# c. Set the y-axis label to ‘Monthly Charges of customer’
# d. Set the title to ‘Tenure vs Monthly Charges’


# In[22]:


# Scatter-Plot
sns.scatterplot(data=df, x=df['tenure'], y=df['MonthlyCharges'], color='brown')
plt.xlabel('Tenure of customer')
plt.ylabel('Monthly Charges of Customer')
plt.title('Tenure vs Monthly Charges')
plt.show()


# In[23]:


## e. Build a box-plot between ‘tenure’ & ‘Contract’. Map ‘tenure’ on the y-asix &
# f. ‘Contract’ on the x-axis

# Boxplot
sns.boxplot(data=df, x=df['Contract'], y=df['tenure'])
plt.show()


# ## Linear Regression

# In[24]:


x = df[['tenure']]
y = df[['MonthlyCharges']]


# In[25]:


x.head()


# In[26]:


y.head()


# ###  Linear Regression:
# #### ● Build a simple linear model where dependent variable is ‘MonthlyCharges’
# ####   and independent variable is ‘tenure’:
# 
# ##### a. Divide the dataset into train and test sets in 70:30 ratio.
# ##### b. Build the model on train set and predict the values on test set
# ##### c. After predicting the values, find the root mean square error
# ##### d. Find out the error in prediction & store the result in ‘error’
# ##### e. Find the root mean square error

# In[27]:


# importing train_test_split and Linear Regression Model and all the metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import *


# In[28]:


# Dividing the dataset into train and test sets in 70:30 ratio.
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.30, random_state=42)


# In[29]:


lr = LinearRegression()


# In[30]:


lr.fit(x_train, y_train)


# In[31]:


y_pred = lr.predict(x_test)


# In[32]:


print(r2_score(y_pred, y_test))


# In[33]:


mse = mean_squared_error(y_test, y_pred)
mse


# In[34]:


error = (np.sqrt(mse))
error


# ### Logistic Regression:
# #### ● Build a simple logistic regression model where dependent variable is
# ####  ‘Churn’ and independent variable is ‘MonthlyCharges’:
# 
# ##### a. Divide the dataset in 65:35 ratio
# ##### b. Build the model on train set and predict the values on test set
# ##### c. Build the confusion matrix and get the accuracy score
# ##### d. Build a multiple logistic regression model where dependent variable
# #####     is ‘Churn’ and independent variables are ‘tenure’ and ‘MonthlyCharges’
# ##### e. Divide the dataset in 80:20 ratio
# ##### f. Build the model on train set and predict the values on test set
# ##### g. Build the confusion matrix and get the accuracy score

# In[35]:


# importing Logistic Regression Model
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression


# In[36]:


x = df[['MonthlyCharges']]
y = df[['Churn']]


# In[37]:


print(x.head())
print(y.head())


# In[38]:


x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.20)


# In[39]:


log_model = LogisticRegression()


# In[40]:


log_model.fit(x_train, y_train)


# In[41]:


y_pred = log_model.predict(x_test)


# In[42]:


accuracy = accuracy_score(y_pred, y_test)
accuracy


# ## Decision Tree:
# #### ● Build a decision tree model where dependent variable is ‘Churn’ and independent variable is ‘tenure’:
# #### a. Divide the dataset in 80:20 ratio
# #### b. Build the model on train set and predict the values on test set
# #### c. Build the confusion matrix and calculate the accuracy.

# In[43]:


# importing decision tree classifier
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix


# In[44]:


x = df[['tenure']]
y = df[['Churn']]


# In[45]:


x.head(5)


# In[46]:


y.head(5)


# In[47]:


x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.20)


# In[48]:


dt_model = DecisionTreeClassifier()


# In[49]:


dt_model.fit(x_train, y_train)


# In[50]:


y_pred = dt_model.predict(x_test)


# In[51]:


print(confusion_matrix(y_pred, y_test))


# ### Random Forest:
# #### Build a Random Forest model where dependent variable is ‘Churn’ and independent variables are ‘tenure’ and ‘MonthlyCharges’:
# #### a. Divide the dataset in 70:30 ratio
# #### b. Build the model on train set and predict the values on test set
# #### c. Build the confusion matrix and calculate

# In[52]:


# importing random forest 
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix


# In[53]:


x = df[['tenure', 'MonthlyCharges']]
y = df[['Churn']]


# In[54]:


x.head(5)


# In[55]:


y.head(5)


# In[56]:


x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.30)


# In[57]:


rf_model = RandomForestClassifier()


# In[59]:


rf_model.fit(x_train, y_train)


# In[60]:


y_pred = rf_model.predict(x_test)


# In[61]:


print(confusion_matrix(y_pred, y_test))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




